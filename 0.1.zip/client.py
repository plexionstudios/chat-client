import socket
import json
import threading
import base64
import eel
import requests
import zipfile
import os, shutil
from time import sleep
from os import path

# Automatic updating
r = requests.get("https://raw.githubusercontent.com/Troned/chat-client/master/version")

file = open("web/version/current","r")
content = file.read()
file.close()

if r.text != content:
    install = input("There is an update available, do you want to install it? [Y/N]\n").lower()
    if install == "y" or install == "yes":

        # Remove all files
        for filename in os.listdir("."):
            filepath = os.path.join(".", filename)
            try:
                shutil.rmtree(filepath)
            except OSError:
                os.remove(filepath)

        new = requests.get(f"https://raw.githubusercontent.com/Troned/chat-client/{r.text}")
        file = open("client.zip","wb")
        file.write(new.content)
        file.close()

        with zipfile.ZipFile("client.zip", 'r') as zip_ref:
            zip_ref.extractall("./")
    else:
        answer = input("Do you want this to be shown again? [Y/N]\n").lower()
        if answer == "n" or answer == "no":
            file = open("web/version/current","w")
            file.write(r.text)

eel.init("web")

FORMAT = "utf-8"
RECAMOUNT = 1024
HEADER = 10

# Using base64 to encode and decode files
def encodeFile(image):
    return base64.b64encode(image).decode(FORMAT)

def decodeFile(image):
    return base64.b64decode(image.encode(FORMAT))

def send(message):
    # Making it easier to send packets
    print(message)
    sock.send(f"{str(len(message)).zfill(HEADER)}{message}".encode(FORMAT))

@eel.expose
def connect(server, port):
    global sock
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((server, port))
    thread = threading.Thread(target=receive)
    thread.start()

# Long bit of code for receiving messages
def receive():
    while True:
        packetsRaw = b""

        # Get entire packet
        header = str(sock.recv(HEADER).decode(FORMAT))
        print(header)

        remain = int(header)
        blockSize = RECAMOUNT


        # This could of been done a nicer way, but TCP is actively trying to break my code
        while remain > 0:
            if remain < blockSize:
                blockSize = remain

            packetsRec = sock.recv(blockSize)
            remain -= len(packetsRec)
            packetsRaw += packetsRec

        packetsRaw = packetsRaw.decode(FORMAT)
        print(f"New packet: {packetsRaw}")

        # Do things with the packet that has to be run with python and not js
        packets = json.loads(packetsRaw)
        for packet in packets:
            if packet == "pfp":
                file = open(f'web/files/pfp/{str(packets[packet]["name"])}',"wb")
                file.write(decodeFile(packets[packet]["image"]))
                file.close()

            elif packet == "message":
                if not path.isfile(f'web/files/pfp/{packets["message"]["pfp"]}'):
                    sendJson = {}
                    sendJson["request"] = {}
                    sendJson["request"]["image"] = packets["message"]["pfp"]
                    send(json.dumps(sendJson))
                    sleep(0.1)
                eel.receive(packets[packet],packet)

            elif packet == "alert":
                if packets[packet]["type"] == "keepAlive":
                    send('{"alert":{"type":"keepAlive"}}')


@eel.expose
def message(message):
    sendJson = {}
    sendJson["message"] = {}
    sendJson["message"]["message"] = message
    send(json.dumps(sendJson))

# I could have this in one function but the if statements would be horrible
@eel.expose
def updateUsername(username):
    file = open("web/config/prev.json","r")
    config = json.loads(file.read())
    config["username"] = username
    file = open("web/config/prev.json","w")
    file.write(json.dumps(config))
    file.close()


@eel.expose
def updateColour(colour):
    file = open("web/config/prev.json","r")
    config = json.loads(file.read())
    config["colour"] = colour
    file = open("web/config/prev.json","w")
    file.write(json.dumps(config))
    file.close()


@eel.expose
def updatePfp(pfp):
    pfp = "".join(pfp.split("base64,")[1:])

    file = open("web/config/prev.json","r")
    config = json.loads(file.read())
    config["pfp"] = pfp

    file = open("web/config/prev.json","w")
    file.write(json.dumps(config))
    file.close()

@eel.expose()
def update():
    file = open("web/config/prev.json")
    send(file.read())


eel.start("index.html", size=(1000,600), port=0)