function message()
{
    eel.message(document.getElementById("messagebox").value);
    document.getElementById("messagebox").value = "";
    document.getElementById("messagebox").rows += 1;
    //document.getElementById("bottom").scrollIntoView();
}

function connect()
{
    server = document.getElementById("server").value;
    port = parseInt(document.getElementById("port").value);
    eel.connect(server,port);
}

eel.expose(receive);
function receive(packet,type)
{
    console.log(packet,type);
    if(!document.hasFocus())
    {
        var audio = new Audio("audio/notif.wav")
        audio.play()
    }
    
    

    if(type === "message")
    {   
        // Set flag if you are at the bottom of a page
        const scroll = true;

        // Markdown for chat messages (this is way too long but ok)
        const md = {
            "*": "strong",
            "_": "u",
            "`": "em"
        };

        var used = {
            "*": false,
            "_": false,
            "`": false
        };

        output = "";
        var escape = false;

        for(charNum = 0; charNum < packet.message.length; charNum++)
        {
            char = packet.message.charAt(charNum);
            
            // Checking if the last character was an escape character
            if(!escape)
            {
                if(char in md)
                {
                    // If you have already started a tag
                    if(used[char])
                    {
                        used[char] = false;
                        output += "</" + md[char] + ">";
                    }
                    
                    // Messy logic to check if there are any other of the same md char after it
                    else if(packet.message.slice(charNum).split(char).length > 2)
                    {
                        used[char] = true;
                        output += "<" + md[char] + ">";
                    }   
                    else
                    {
                        output += char;
                    }
                }

                // Colours
                else if(char === "&")
                {
                    var a = 0;
                    var charNext;
                    var colour = "";
                    while(true)
                    {
                        charNum += 1;
                        charNext = packet.message.charAt(charNum);
                        if(charNext === "&")
                        {
                            break;
                        }
                        else
                        {
                            colour += parseHtml(charNext);
                        }
                    }

                    if(colour === "")
                    {
                        output += "</span>";
                    }
                    else
                    {
                        output += '<span style="color:' + colour + '">';
                    }
                }

                else
                {
                    if(char != "\\")
                    {
                        output += parseHtml(char);
                    }
                }
            }
            else
            {
                // If you escaped character then reset var escape and add the character normally 
                output += parseHtml(char);
                escape = false;
            }

            // Check if backslash and if so escape
            if(char === "\\")
            {
                escape = true;
            }
        }

        // Putting together username with colour
        username = '<span style="color:' + parseHtml(packet.colour) + '">' + parseHtml(packet.username) + '</span>'

        // Creating the template and setting the right parts to the right things
        var template = document.querySelector('#messagetemplate');
        
        template.content.getElementById("pfp").src = "files/pfp/" + packet.pfp;
        template.content.getElementById("username").innerHTML = username;
        template.content.getElementById("message").innerHTML = output;

        var clone = document.importNode(template.content, true);
        chatarea = document.getElementById("chatarea");

        // Bit of logic to put it before the "bottom" div and padding
        chatarea.insertBefore(clone, chatarea.childNodes[chatarea.childNodes.length - 4]);

        if(scroll)
        {
            document.getElementById("bottom").scrollIntoView();
        }
    }
}

function update()
{
    eel.update()
}

function updatePfp(event)
{
    var input = event.target;

    // Stolen code from somewhere I accidentally deleted the note that said where
    var reader = new FileReader();
    reader.onload = function()
    {
        var dataURL = reader.result;
        eel.updatePfp(dataURL);

        document.getElementById("pfpimg").src = dataURL;
    }
    reader.readAsDataURL(input.files[0]);
}

function updateUsername()
{
    username = document.getElementById("name").value
    eel.updateUsername(username);
}

function updateColour()
{
    colour = document.getElementById("colour").value
    eel.updateColour(colour);
}

function pfpClick()
{
    document.getElementById('pfpselect').click();
}

// Parse HTML so people cant add script tags to their messages
function parseHtml(html)
{
    return html.replace("<","&lt").replace(">","&gt")
}

window.addEventListener('resize', function(event)
{
    const windowWidth = window.innerWidth;
    messageBoxLen = window.innerWidth - 240;
    document.getElementById("messagebox").style.width = messageBoxLen + "px";
});

const windowWidth = window.innerWidth;
messageBoxLen = window.innerWidth - 240;
document.getElementById("messagebox").style.width = messageBoxLen + "px";

// Get keyboard presses
window.addEventListener("keydown", keyPress, false);
window.addEventListener("keyup", keyRelease, false);

var pressedKeys = {}
function keyPress(key)
{
    pressedKeys[key.keyCode] = true;

    if(document.activeElement === document.body)
    {
        document.getElementById("messagebox").focus()
    }
}

function keyRelease(key)
{
    pressedKeys[key.keyCode] = false;
}